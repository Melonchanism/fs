Dwarven Mines Mithril Cube - Adjustable XYZ (Java 1.21.9+ through 26.3)

Install ZIP into your world's datapacks folder and run /reload.

SPAWN AT ANY XYZ (center of cube):
/function mithril:setup (centered at your current position)
/execute positioned 100 70 -30 run function mithril:setup (center at X100 Y70 Z-30)

In ONE repeating always-active command block:
function mithril:tick

Cube is 5x5x5, spanning center +/- 2 blocks each axis.
Each mined block changes to bedrock, then independently regrows after ~5 seconds.
2% chance polished diorite (Titanium stand-in).
Multiple cubes may coexist. Running setup again at the same position replaces those markers instead of duplicating them.

Remove ALL regeneration markers: /function mithril:stop
Blocks remain in place. Requires loaded chunks. Vanilla block drops/mining speed.

scoreboard objectives add mithril_timer dummy
scoreboard objectives add mithril_roll dummy
setblock ~-2 ~-2 ~-2 minecraft:light_blue_wool
execute positioned ~-2 ~-2 ~-2 run kill @e[type=minecraft:marker,tag=mithril_node,distance=..0.1]
summon minecraft:marker ~-2 ~-2 ~-2 {Tags:["mithril_node","mithril_light_blue_wool"]}
setblock ~-2 ~-2 ~-1 minecraft:prismarine_bricks
execute positioned ~-2 ~-2 ~-1 run kill @e[type=minecraft:marker,tag=mithril_node,distance=..0.1]
summon minecraft:marker ~-2 ~-2 ~-1 {Tags:["mithril_node","mithril_prismarine_bricks"]}
setblock ~-2 ~-2 ~ minecraft:prismarine_bricks
execute positioned ~-2 ~-2 ~ run kill @e[type=minecraft:marker,tag=mithril_node,distance=..0.1]
summon minecraft:marker ~-2 ~-2 ~ {Tags:["mithril_node","mithril_prismarine_bricks"]}
setblock ~-2 ~-2 ~1 minecraft:dark_prismarine
execute positioned ~-2 ~-2 ~1 run kill @e[type=minecraft:marker,tag=mithril_node,distance=..0.1]
summon minecraft:marker ~-2 ~-2 ~1 {Tags:["mithril_node","mithril_dark_prismarine"]}
setblock ~-2 ~-2 ~2 minecraft:cyan_terracotta
execute positioned ~-2 ~-2 ~2 run kill @e[type=minecraft:marker,tag=mithril_node,distance=..0.1]
summon minecraft:marker ~-2 ~-2 ~2 {Tags:["mithril_node","mithril_cyan_terracotta"]}
setblock ~-2 ~-1 ~-2 minecraft:dark_prismarine
execute positioned ~-2 ~-1 ~-2 run kill @e[type=minecraft:marker,tag=mithril_node,distance=..0.1]
summon minecraft:marker ~-2 ~-1 ~-2 {Tags:["mithril_node","mithril_dark_prismarine"]}
setblock ~-2 ~-1 ~-1 minecraft:cyan_terracotta
execute positioned ~-2 ~-1 ~-1 run kill @e[type=minecraft:marker,tag=mithril_node,distance=..0.1]
summon minecraft:marker ~-2 ~-1 ~-1 {Tags:["mithril_node","mithril_cyan_terracotta"]}
setblock ~-2 ~-1 ~ minecraft:cyan_terracotta
execute positioned ~-2 ~-1 ~ run kill @e[type=minecraft:marker,tag=mithril_node,distance=..0.1]
summon minecraft:marker ~-2 ~-1 ~ {Tags:["mithril_node","mithril_cyan_terracotta"]}
setblock ~-2 ~-1 ~1 minecraft:gray_wool
execute positioned ~-2 ~-1 ~1 run kill @e[type=minecraft:marker,tag=mithril_node,distance=..0.1]
summon minecraft:marker ~-2 ~-1 ~1 {Tags:["mithril_node","mithril_gray_wool"]}
setblock ~-2 ~-1 ~2 minecraft:prismarine
execute positioned ~-2 ~-1 ~2 run kill @e[type=minecraft:marker,tag=mithril_node,distance=..0.1]
summon minecraft:marker ~-2 ~-1 ~2 {Tags:["mithril_node","mithril_prismarine"]}
setblock ~-2 ~ ~-2 minecraft:gray_wool
execute positioned ~-2 ~ ~-2 run kill @e[type=minecraft:marker,tag=mithril_node,distance=..0.1]
summon minecraft:marker ~-2 ~ ~-2 {Tags:["mithril_node","mithril_gray_wool"]}
setblock ~-2 ~ ~-1 minecraft:prismarine
execute positioned ~-2 ~ ~-1 run kill @e[type=minecraft:marker,tag=mithril_node,distance=..0.1]
summon minecraft:marker ~-2 ~ ~-1 {Tags:["mithril_node","mithril_prismarine"]}
setblock ~-2 ~ ~ minecraft:prismarine
execute positioned ~-2 ~ ~ run kill @e[type=minecraft:marker,tag=mithril_node,distance=..0.1]
summon minecraft:marker ~-2 ~ ~ {Tags:["mithril_node","mithril_prismarine"]}
setblock ~-2 ~ ~1 minecraft:prismarine
execute positioned ~-2 ~ ~1 run kill @e[type=minecraft:marker,tag=mithril_node,distance=..0.1]
summon minecraft:marker ~-2 ~ ~1 {Tags:["mithril_node","mithril_prismarine"]}
setblock ~-2 ~ ~2 minecraft:light_blue_wool
execute positioned ~-2 ~ ~2 run kill @e[type=minecraft:marker,tag=mithril_node,distance=..0.1]
summon minecraft:marker ~-2 ~ ~2 {Tags:["mithril_node","mithril_light_blue_wool"]}
setblock ~-2 ~1 ~-2 minecraft:prismarine
execute positioned ~-2 ~1 ~-2 run kill @e[type=minecraft:marker,tag=mithril_node,distance=..0.1]
summon minecraft:marker ~-2 ~1 ~-2 {Tags:["mithril_node","mithril_prismarine"]}
setblock ~-2 ~1 ~-1 minecraft:light_blue_wool
execute positioned ~-2 ~1 ~-1 run kill @e[type=minecraft:marker,tag=mithril_node,distance=..0.1]
summon minecraft:marker ~-2 ~1 ~-1 {Tags:["mithril_node","mithril_light_blue_wool"]}
setblock ~-2 ~1 ~ minecraft:prismarine_bricks
execute positioned ~-2 ~1 ~ run kill @e[type=minecraft:marker,tag=mithril_node,distance=..0.1]
summon minecraft:marker ~-2 ~1 ~ {Tags:["mithril_node","mithril_prismarine_bricks"]}
setblock ~-2 ~1 ~1 minecraft:prismarine_bricks
execute positioned ~-2 ~1 ~1 run kill @e[type=minecraft:marker,tag=mithril_node,distance=..0.1]
summon minecraft:marker ~-2 ~1 ~1 {Tags:["mithril_node","mithril_prismarine_bricks"]}
setblock ~-2 ~1 ~2 minecraft:dark_prismarine
execute positioned ~-2 ~1 ~2 run kill @e[type=minecraft:marker,tag=mithril_node,distance=..0.1]
summon minecraft:marker ~-2 ~1 ~2 {Tags:["mithril_node","mithril_dark_prismarine"]}
setblock ~-2 ~2 ~-2 minecraft:prismarine_bricks
execute positioned ~-2 ~2 ~-2 run kill @e[type=minecraft:marker,tag=mithril_node,distance=..0.1]
summon minecraft:marker ~-2 ~2 ~-2 {Tags:["mithril_node","mithril_prismarine_bricks"]}
setblock ~-2 ~2 ~-1 minecraft:dark_prismarine
execute positioned ~-2 ~2 ~-1 run kill @e[type=minecraft:marker,tag=mithril_node,distance=..0.1]
summon minecraft:marker ~-2 ~2 ~-1 {Tags:["mithril_node","mithril_dark_prismarine"]}
setblock ~-2 ~2 ~ minecraft:cyan_terracotta
execute positioned ~-2 ~2 ~ run kill @e[type=minecraft:marker,tag=mithril_node,distance=..0.1]
summon minecraft:marker ~-2 ~2 ~ {Tags:["mithril_node","mithril_cyan_terracotta"]}
setblock ~-2 ~2 ~1 minecraft:cyan_terracotta
execute positioned ~-2 ~2 ~1 run kill @e[type=minecraft:marker,tag=mithril_node,distance=..0.1]
summon minecraft:marker ~-2 ~2 ~1 {Tags:["mithril_node","mithril_cyan_terracotta"]}
setblock ~-2 ~2 ~2 minecraft:gray_wool
execute positioned ~-2 ~2 ~2 run kill @e[type=minecraft:marker,tag=mithril_node,distance=..0.1]
summon minecraft:marker ~-2 ~2 ~2 {Tags:["mithril_node","mithril_gray_wool"]}
setblock ~-1 ~-2 ~-2 minecraft:prismarine
execute positioned ~-1 ~-2 ~-2 run kill @e[type=minecraft:marker,tag=mithril_node,distance=..0.1]
summon minecraft:marker ~-1 ~-2 ~-2 {Tags:["mithril_node","mithril_prismarine"]}
setblock ~-1 ~-2 ~-1 minecraft:prismarine
execute positioned ~-1 ~-2 ~-1 run kill @e[type=minecraft:marker,tag=mithril_node,distance=..0.1]
summon minecraft:marker ~-1 ~-2 ~-1 {Tags:["mithril_node","mithril_prismarine"]}
setblock ~-1 ~-2 ~ minecraft:prismarine
execute positioned ~-1 ~-2 ~ run kill @e[type=minecraft:marker,tag=mithril_node,distance=..0.1]
summon minecraft:marker ~-1 ~-2 ~ {Tags:["mithril_node","mithril_prismarine"]}
setblock ~-1 ~-2 ~1 minecraft:light_blue_wool
execute positioned ~-1 ~-2 ~1 run kill @e[type=minecraft:marker,tag=mithril_node,distance=..0.1]
summon minecraft:marker ~-1 ~-2 ~1 {Tags:["mithril_node","mithril_light_blue_wool"]}
setblock ~-1 ~-2 ~2 minecraft:prismarine_bricks
execute positioned ~-1 ~-2 ~2 run kill @e[type=minecraft:marker,tag=mithril_node,distance=..0.1]
summon minecraft:marker ~-1 ~-2 ~2 {Tags:["mithril_node","mithril_prismarine_bricks"]}
setblock ~-1 ~-1 ~-2 minecraft:light_blue_wool
execute positioned ~-1 ~-1 ~-2 run kill @e[type=minecraft:marker,tag=mithril_node,distance=..0.1]
summon minecraft:marker ~-1 ~-1 ~-2 {Tags:["mithril_node","mithril_light_blue_wool"]}
setblock ~-1 ~-1 ~-1 minecraft:prismarine_bricks
execute positioned ~-1 ~-1 ~-1 run kill @e[type=minecraft:marker,tag=mithril_node,distance=..0.1]
summon minecraft:marker ~-1 ~-1 ~-1 {Tags:["mithril_node","mithril_prismarine_bricks"]}
setblock ~-1 ~-1 ~ minecraft:prismarine_bricks
execute positioned ~-1 ~-1 ~ run kill @e[type=minecraft:marker,tag=mithril_node,distance=..0.1]
summon minecraft:marker ~-1 ~-1 ~ {Tags:["mithril_node","mithril_prismarine_bricks"]}
setblock ~-1 ~-1 ~1 minecraft:dark_prismarine
execute positioned ~-1 ~-1 ~1 run kill @e[type=minecraft:marker,tag=mithril_node,distance=..0.1]
summon minecraft:marker ~-1 ~-1 ~1 {Tags:["mithril_node","mithril_dark_prismarine"]}
setblock ~-1 ~-1 ~2 minecraft:cyan_terracotta
execute positioned ~-1 ~-1 ~2 run kill @e[type=minecraft:marker,tag=mithril_node,distance=..0.1]
summon minecraft:marker ~-1 ~-1 ~2 {Tags:["mithril_node","mithril_cyan_terracotta"]}
setblock ~-1 ~ ~-2 minecraft:dark_prismarine
execute positioned ~-1 ~ ~-2 run kill @e[type=minecraft:marker,tag=mithril_node,distance=..0.1]
summon minecraft:marker ~-1 ~ ~-2 {Tags:["mithril_node","mithril_dark_prismarine"]}
setblock ~-1 ~ ~-1 minecraft:cyan_terracotta
execute positioned ~-1 ~ ~-1 run kill @e[type=minecraft:marker,tag=mithril_node,distance=..0.1]
summon minecraft:marker ~-1 ~ ~-1 {Tags:["mithril_node","mithril_cyan_terracotta"]}
setblock ~-1 ~ ~ minecraft:cyan_terracotta
execute positioned ~-1 ~ ~ run kill @e[type=minecraft:marker,tag=mithril_node,distance=..0.1]
summon minecraft:marker ~-1 ~ ~ {Tags:["mithril_node","mithril_cyan_terracotta"]}
setblock ~-1 ~ ~1 minecraft:gray_wool
execute positioned ~-1 ~ ~1 run kill @e[type=minecraft:marker,tag=mithril_node,distance=..0.1]
summon minecraft:marker ~-1 ~ ~1 {Tags:["mithril_node","mithril_gray_wool"]}
setblock ~-1 ~ ~2 minecraft:prismarine
execute positioned ~-1 ~ ~2 run kill @e[type=minecraft:marker,tag=mithril_node,distance=..0.1]
summon minecraft:marker ~-1 ~ ~2 {Tags:["mithril_node","mithril_prismarine"]}
setblock ~-1 ~1 ~-2 minecraft:gray_wool
execute positioned ~-1 ~1 ~-2 run kill @e[type=minecraft:marker,tag=mithril_node,distance=..0.1]
summon minecraft:marker ~-1 ~1 ~-2 {Tags:["mithril_node","mithril_gray_wool"]}
setblock ~-1 ~1 ~-1 minecraft:prismarine
execute positioned ~-1 ~1 ~-1 run kill @e[type=minecraft:marker,tag=mithril_node,distance=..0.1]
summon minecraft:marker ~-1 ~1 ~-1 {Tags:["mithril_node","mithril_prismarine"]}
setblock ~-1 ~1 ~ minecraft:prismarine
execute positioned ~-1 ~1 ~ run kill @e[type=minecraft:marker,tag=mithril_node,distance=..0.1]
summon minecraft:marker ~-1 ~1 ~ {Tags:["mithril_node","mithril_prismarine"]}
setblock ~-1 ~1 ~1 minecraft:prismarine
execute positioned ~-1 ~1 ~1 run kill @e[type=minecraft:marker,tag=mithril_node,distance=..0.1]
summon minecraft:marker ~-1 ~1 ~1 {Tags:["mithril_node","mithril_prismarine"]}
setblock ~-1 ~1 ~2 minecraft:light_blue_wool
execute positioned ~-1 ~1 ~2 run kill @e[type=minecraft:marker,tag=mithril_node,distance=..0.1]
summon minecraft:marker ~-1 ~1 ~2 {Tags:["mithril_node","mithril_light_blue_wool"]}
setblock ~-1 ~2 ~-2 minecraft:prismarine
execute positioned ~-1 ~2 ~-2 run kill @e[type=minecraft:marker,tag=mithril_node,distance=..0.1]
summon minecraft:marker ~-1 ~2 ~-2 {Tags:["mithril_node","mithril_prismarine"]}
setblock ~-1 ~2 ~-1 minecraft:light_blue_wool
execute positioned ~-1 ~2 ~-1 run kill @e[type=minecraft:marker,tag=mithril_node,distance=..0.1]
summon minecraft:marker ~-1 ~2 ~-1 {Tags:["mithril_node","mithril_light_blue_wool"]}
setblock ~-1 ~2 ~ minecraft:prismarine_bricks
execute positioned ~-1 ~2 ~ run kill @e[type=minecraft:marker,tag=mithril_node,distance=..0.1]
summon minecraft:marker ~-1 ~2 ~ {Tags:["mithril_node","mithril_prismarine_bricks"]}
setblock ~-1 ~2 ~1 minecraft:prismarine_bricks
execute positioned ~-1 ~2 ~1 run kill @e[type=minecraft:marker,tag=mithril_node,distance=..0.1]
summon minecraft:marker ~-1 ~2 ~1 {Tags:["mithril_node","mithril_prismarine_bricks"]}
setblock ~-1 ~2 ~2 minecraft:dark_prismarine
execute positioned ~-1 ~2 ~2 run kill @e[type=minecraft:marker,tag=mithril_node,distance=..0.1]
summon minecraft:marker ~-1 ~2 ~2 {Tags:["mithril_node","mithril_dark_prismarine"]}
setblock ~ ~-2 ~-2 minecraft:cyan_terracotta
execute positioned ~ ~-2 ~-2 run kill @e[type=minecraft:marker,tag=mithril_node,distance=..0.1]
summon minecraft:marker ~ ~-2 ~-2 {Tags:["mithril_node","mithril_cyan_terracotta"]}
setblock ~ ~-2 ~-1 minecraft:cyan_terracotta
execute positioned ~ ~-2 ~-1 run kill @e[type=minecraft:marker,tag=mithril_node,distance=..0.1]
summon minecraft:marker ~ ~-2 ~-1 {Tags:["mithril_node","mithril_cyan_terracotta"]}
setblock ~ ~-2 ~ minecraft:gray_wool
execute positioned ~ ~-2 ~ run kill @e[type=minecraft:marker,tag=mithril_node,distance=..0.1]
summon minecraft:marker ~ ~-2 ~ {Tags:["mithril_node","mithril_gray_wool"]}
setblock ~ ~-2 ~1 minecraft:prismarine
execute positioned ~ ~-2 ~1 run kill @e[type=minecraft:marker,tag=mithril_node,distance=..0.1]
summon minecraft:marker ~ ~-2 ~1 {Tags:["mithril_node","mithril_prismarine"]}
setblock ~ ~-2 ~2 minecraft:prismarine
execute positioned ~ ~-2 ~2 run kill @e[type=minecraft:marker,tag=mithril_node,distance=..0.1]
summon minecraft:marker ~ ~-2 ~2 {Tags:["mithril_node","mithril_prismarine"]}
setblock ~ ~-1 ~-2 minecraft:prismarine
execute positioned ~ ~-1 ~-2 run kill @e[type=minecraft:marker,tag=mithril_node,distance=..0.1]
summon minecraft:marker ~ ~-1 ~-2 {Tags:["mithril_node","mithril_prismarine"]}
setblock ~ ~-1 ~-1 minecraft:prismarine
execute positioned ~ ~-1 ~-1 run kill @e[type=minecraft:marker,tag=mithril_node,distance=..0.1]
summon minecraft:marker ~ ~-1 ~-1 {Tags:["mithril_node","mithril_prismarine"]}
setblock ~ ~-1 ~ minecraft:prismarine
execute positioned ~ ~-1 ~ run kill @e[type=minecraft:marker,tag=mithril_node,distance=..0.1]
summon minecraft:marker ~ ~-1 ~ {Tags:["mithril_node","mithril_prismarine"]}
setblock ~ ~-1 ~1 minecraft:light_blue_wool
execute positioned ~ ~-1 ~1 run kill @e[type=minecraft:marker,tag=mithril_node,distance=..0.1]
summon minecraft:marker ~ ~-1 ~1 {Tags:["mithril_node","mithril_light_blue_wool"]}
setblock ~ ~-1 ~2 minecraft:prismarine_bricks
execute positioned ~ ~-1 ~2 run kill @e[type=minecraft:marker,tag=mithril_node,distance=..0.1]
summon minecraft:marker ~ ~-1 ~2 {Tags:["mithril_node","mithril_prismarine_bricks"]}
setblock ~ ~ ~-2 minecraft:light_blue_wool
execute positioned ~ ~ ~-2 run kill @e[type=minecraft:marker,tag=mithril_node,distance=..0.1]
summon minecraft:marker ~ ~ ~-2 {Tags:["mithril_node","mithril_light_blue_wool"]}
setblock ~ ~ ~-1 minecraft:prismarine_bricks
execute positioned ~ ~ ~-1 run kill @e[type=minecraft:marker,tag=mithril_node,distance=..0.1]
summon minecraft:marker ~ ~ ~-1 {Tags:["mithril_node","mithril_prismarine_bricks"]}
setblock ~ ~ ~ minecraft:prismarine_bricks
execute positioned ~ ~ ~ run kill @e[type=minecraft:marker,tag=mithril_node,distance=..0.1]
summon minecraft:marker ~ ~ ~ {Tags:["mithril_node","mithril_prismarine_bricks"]}
setblock ~ ~ ~1 minecraft:dark_prismarine
execute positioned ~ ~ ~1 run kill @e[type=minecraft:marker,tag=mithril_node,distance=..0.1]
summon minecraft:marker ~ ~ ~1 {Tags:["mithril_node","mithril_dark_prismarine"]}
setblock ~ ~ ~2 minecraft:cyan_terracotta
execute positioned ~ ~ ~2 run kill @e[type=minecraft:marker,tag=mithril_node,distance=..0.1]
summon minecraft:marker ~ ~ ~2 {Tags:["mithril_node","mithril_cyan_terracotta"]}
setblock ~ ~1 ~-2 minecraft:dark_prismarine
execute positioned ~ ~1 ~-2 run kill @e[type=minecraft:marker,tag=mithril_node,distance=..0.1]
summon minecraft:marker ~ ~1 ~-2 {Tags:["mithril_node","mithril_dark_prismarine"]}
setblock ~ ~1 ~-1 minecraft:cyan_terracotta
execute positioned ~ ~1 ~-1 run kill @e[type=minecraft:marker,tag=mithril_node,distance=..0.1]
summon minecraft:marker ~ ~1 ~-1 {Tags:["mithril_node","mithril_cyan_terracotta"]}
setblock ~ ~1 ~ minecraft:cyan_terracotta
execute positioned ~ ~1 ~ run kill @e[type=minecraft:marker,tag=mithril_node,distance=..0.1]
summon minecraft:marker ~ ~1 ~ {Tags:["mithril_node","mithril_cyan_terracotta"]}
setblock ~ ~1 ~1 minecraft:gray_wool
execute positioned ~ ~1 ~1 run kill @e[type=minecraft:marker,tag=mithril_node,distance=..0.1]
summon minecraft:marker ~ ~1 ~1 {Tags:["mithril_node","mithril_gray_wool"]}
setblock ~ ~1 ~2 minecraft:prismarine
execute positioned ~ ~1 ~2 run kill @e[type=minecraft:marker,tag=mithril_node,distance=..0.1]
summon minecraft:marker ~ ~1 ~2 {Tags:["mithril_node","mithril_prismarine"]}
setblock ~ ~2 ~-2 minecraft:gray_wool
execute positioned ~ ~2 ~-2 run kill @e[type=minecraft:marker,tag=mithril_node,distance=..0.1]
summon minecraft:marker ~ ~2 ~-2 {Tags:["mithril_node","mithril_gray_wool"]}
setblock ~ ~2 ~-1 minecraft:prismarine
execute positioned ~ ~2 ~-1 run kill @e[type=minecraft:marker,tag=mithril_node,distance=..0.1]
summon minecraft:marker ~ ~2 ~-1 {Tags:["mithril_node","mithril_prismarine"]}
setblock ~ ~2 ~ minecraft:prismarine
execute positioned ~ ~2 ~ run kill @e[type=minecraft:marker,tag=mithril_node,distance=..0.1]
summon minecraft:marker ~ ~2 ~ {Tags:["mithril_node","mithril_prismarine"]}
setblock ~ ~2 ~1 minecraft:prismarine
execute positioned ~ ~2 ~1 run kill @e[type=minecraft:marker,tag=mithril_node,distance=..0.1]
summon minecraft:marker ~ ~2 ~1 {Tags:["mithril_node","mithril_prismarine"]}
setblock ~ ~2 ~2 minecraft:light_blue_wool
execute positioned ~ ~2 ~2 run kill @e[type=minecraft:marker,tag=mithril_node,distance=..0.1]
summon minecraft:marker ~ ~2 ~2 {Tags:["mithril_node","mithril_light_blue_wool"]}
setblock ~1 ~-2 ~-2 minecraft:prismarine_bricks
execute positioned ~1 ~-2 ~-2 run kill @e[type=minecraft:marker,tag=mithril_node,distance=..0.1]
summon minecraft:marker ~1 ~-2 ~-2 {Tags:["mithril_node","mithril_prismarine_bricks"]}
setblock ~1 ~-2 ~-1 minecraft:prismarine_bricks
execute positioned ~1 ~-2 ~-1 run kill @e[type=minecraft:marker,tag=mithril_node,distance=..0.1]
summon minecraft:marker ~1 ~-2 ~-1 {Tags:["mithril_node","mithril_prismarine_bricks"]}
setblock ~1 ~-2 ~ minecraft:dark_prismarine
execute positioned ~1 ~-2 ~ run kill @e[type=minecraft:marker,tag=mithril_node,distance=..0.1]
summon minecraft:marker ~1 ~-2 ~ {Tags:["mithril_node","mithril_dark_prismarine"]}
setblock ~1 ~-2 ~1 minecraft:cyan_terracotta
execute positioned ~1 ~-2 ~1 run kill @e[type=minecraft:marker,tag=mithril_node,distance=..0.1]
summon minecraft:marker ~1 ~-2 ~1 {Tags:["mithril_node","mithril_cyan_terracotta"]}
setblock ~1 ~-2 ~2 minecraft:cyan_terracotta
execute positioned ~1 ~-2 ~2 run kill @e[type=minecraft:marker,tag=mithril_node,distance=..0.1]
summon minecraft:marker ~1 ~-2 ~2 {Tags:["mithril_node","mithril_cyan_terracotta"]}
setblock ~1 ~-1 ~-2 minecraft:cyan_terracotta
execute positioned ~1 ~-1 ~-2 run kill @e[type=minecraft:marker,tag=mithril_node,distance=..0.1]
summon minecraft:marker ~1 ~-1 ~-2 {Tags:["mithril_node","mithril_cyan_terracotta"]}
setblock ~1 ~-1 ~-1 minecraft:cyan_terracotta
execute positioned ~1 ~-1 ~-1 run kill @e[type=minecraft:marker,tag=mithril_node,distance=..0.1]
summon minecraft:marker ~1 ~-1 ~-1 {Tags:["mithril_node","mithril_cyan_terracotta"]}
setblock ~1 ~-1 ~ minecraft:gray_wool
execute positioned ~1 ~-1 ~ run kill @e[type=minecraft:marker,tag=mithril_node,distance=..0.1]
summon minecraft:marker ~1 ~-1 ~ {Tags:["mithril_node","mithril_gray_wool"]}
setblock ~1 ~-1 ~1 minecraft:prismarine
execute positioned ~1 ~-1 ~1 run kill @e[type=minecraft:marker,tag=mithril_node,distance=..0.1]
summon minecraft:marker ~1 ~-1 ~1 {Tags:["mithril_node","mithril_prismarine"]}
setblock ~1 ~-1 ~2 minecraft:prismarine
execute positioned ~1 ~-1 ~2 run kill @e[type=minecraft:marker,tag=mithril_node,distance=..0.1]
summon minecraft:marker ~1 ~-1 ~2 {Tags:["mithril_node","mithril_prismarine"]}
setblock ~1 ~ ~-2 minecraft:prismarine
execute positioned ~1 ~ ~-2 run kill @e[type=minecraft:marker,tag=mithril_node,distance=..0.1]
summon minecraft:marker ~1 ~ ~-2 {Tags:["mithril_node","mithril_prismarine"]}
setblock ~1 ~ ~-1 minecraft:prismarine
execute positioned ~1 ~ ~-1 run kill @e[type=minecraft:marker,tag=mithril_node,distance=..0.1]
summon minecraft:marker ~1 ~ ~-1 {Tags:["mithril_node","mithril_prismarine"]}
setblock ~1 ~ ~ minecraft:prismarine
execute positioned ~1 ~ ~ run kill @e[type=minecraft:marker,tag=mithril_node,distance=..0.1]
summon minecraft:marker ~1 ~ ~ {Tags:["mithril_node","mithril_prismarine"]}
setblock ~1 ~ ~1 minecraft:light_blue_wool
execute positioned ~1 ~ ~1 run kill @e[type=minecraft:marker,tag=mithril_node,distance=..0.1]
summon minecraft:marker ~1 ~ ~1 {Tags:["mithril_node","mithril_light_blue_wool"]}
setblock ~1 ~ ~2 minecraft:prismarine_bricks
execute positioned ~1 ~ ~2 run kill @e[type=minecraft:marker,tag=mithril_node,distance=..0.1]
summon minecraft:marker ~1 ~ ~2 {Tags:["mithril_node","mithril_prismarine_bricks"]}
setblock ~1 ~1 ~-2 minecraft:light_blue_wool
execute positioned ~1 ~1 ~-2 run kill @e[type=minecraft:marker,tag=mithril_node,distance=..0.1]
summon minecraft:marker ~1 ~1 ~-2 {Tags:["mithril_node","mithril_light_blue_wool"]}
setblock ~1 ~1 ~-1 minecraft:prismarine_bricks
execute positioned ~1 ~1 ~-1 run kill @e[type=minecraft:marker,tag=mithril_node,distance=..0.1]
summon minecraft:marker ~1 ~1 ~-1 {Tags:["mithril_node","mithril_prismarine_bricks"]}
setblock ~1 ~1 ~ minecraft:prismarine_bricks
execute positioned ~1 ~1 ~ run kill @e[type=minecraft:marker,tag=mithril_node,distance=..0.1]
summon minecraft:marker ~1 ~1 ~ {Tags:["mithril_node","mithril_prismarine_bricks"]}
setblock ~1 ~1 ~1 minecraft:dark_prismarine
execute positioned ~1 ~1 ~1 run kill @e[type=minecraft:marker,tag=mithril_node,distance=..0.1]
summon minecraft:marker ~1 ~1 ~1 {Tags:["mithril_node","mithril_dark_prismarine"]}
setblock ~1 ~1 ~2 minecraft:cyan_terracotta
execute positioned ~1 ~1 ~2 run kill @e[type=minecraft:marker,tag=mithril_node,distance=..0.1]
summon minecraft:marker ~1 ~1 ~2 {Tags:["mithril_node","mithril_cyan_terracotta"]}
setblock ~1 ~2 ~-2 minecraft:dark_prismarine
execute positioned ~1 ~2 ~-2 run kill @e[type=minecraft:marker,tag=mithril_node,distance=..0.1]
summon minecraft:marker ~1 ~2 ~-2 {Tags:["mithril_node","mithril_dark_prismarine"]}
setblock ~1 ~2 ~-1 minecraft:cyan_terracotta
execute positioned ~1 ~2 ~-1 run kill @e[type=minecraft:marker,tag=mithril_node,distance=..0.1]
summon minecraft:marker ~1 ~2 ~-1 {Tags:["mithril_node","mithril_cyan_terracotta"]}
setblock ~1 ~2 ~ minecraft:cyan_terracotta
execute positioned ~1 ~2 ~ run kill @e[type=minecraft:marker,tag=mithril_node,distance=..0.1]
summon minecraft:marker ~1 ~2 ~ {Tags:["mithril_node","mithril_cyan_terracotta"]}
setblock ~1 ~2 ~1 minecraft:gray_wool
execute positioned ~1 ~2 ~1 run kill @e[type=minecraft:marker,tag=mithril_node,distance=..0.1]
summon minecraft:marker ~1 ~2 ~1 {Tags:["mithril_node","mithril_gray_wool"]}
setblock ~1 ~2 ~2 minecraft:prismarine
execute positioned ~1 ~2 ~2 run kill @e[type=minecraft:marker,tag=mithril_node,distance=..0.1]
summon minecraft:marker ~1 ~2 ~2 {Tags:["mithril_node","mithril_prismarine"]}
setblock ~2 ~-2 ~-2 minecraft:prismarine
execute positioned ~2 ~-2 ~-2 run kill @e[type=minecraft:marker,tag=mithril_node,distance=..0.1]
summon minecraft:marker ~2 ~-2 ~-2 {Tags:["mithril_node","mithril_prismarine"]}
setblock ~2 ~-2 ~-1 minecraft:prismarine
execute positioned ~2 ~-2 ~-1 run kill @e[type=minecraft:marker,tag=mithril_node,distance=..0.1]
summon minecraft:marker ~2 ~-2 ~-1 {Tags:["mithril_node","mithril_prismarine"]}
setblock ~2 ~-2 ~ minecraft:light_blue_wool
execute positioned ~2 ~-2 ~ run kill @e[type=minecraft:marker,tag=mithril_node,distance=..0.1]
summon minecraft:marker ~2 ~-2 ~ {Tags:["mithril_node","mithril_light_blue_wool"]}
setblock ~2 ~-2 ~1 minecraft:prismarine_bricks
execute positioned ~2 ~-2 ~1 run kill @e[type=minecraft:marker,tag=mithril_node,distance=..0.1]
summon minecraft:marker ~2 ~-2 ~1 {Tags:["mithril_node","mithril_prismarine_bricks"]}
setblock ~2 ~-2 ~2 minecraft:prismarine_bricks
execute positioned ~2 ~-2 ~2 run kill @e[type=minecraft:marker,tag=mithril_node,distance=..0.1]
summon minecraft:marker ~2 ~-2 ~2 {Tags:["mithril_node","mithril_prismarine_bricks"]}
setblock ~2 ~-1 ~-2 minecraft:prismarine_bricks
execute positioned ~2 ~-1 ~-2 run kill @e[type=minecraft:marker,tag=mithril_node,distance=..0.1]
summon minecraft:marker ~2 ~-1 ~-2 {Tags:["mithril_node","mithril_prismarine_bricks"]}
setblock ~2 ~-1 ~-1 minecraft:prismarine_bricks
execute positioned ~2 ~-1 ~-1 run kill @e[type=minecraft:marker,tag=mithril_node,distance=..0.1]
summon minecraft:marker ~2 ~-1 ~-1 {Tags:["mithril_node","mithril_prismarine_bricks"]}
setblock ~2 ~-1 ~ minecraft:dark_prismarine
execute positioned ~2 ~-1 ~ run kill @e[type=minecraft:marker,tag=mithril_node,distance=..0.1]
summon minecraft:marker ~2 ~-1 ~ {Tags:["mithril_node","mithril_dark_prismarine"]}
setblock ~2 ~-1 ~1 minecraft:cyan_terracotta
execute positioned ~2 ~-1 ~1 run kill @e[type=minecraft:marker,tag=mithril_node,distance=..0.1]
summon minecraft:marker ~2 ~-1 ~1 {Tags:["mithril_node","mithril_cyan_terracotta"]}
setblock ~2 ~-1 ~2 minecraft:cyan_terracotta
execute positioned ~2 ~-1 ~2 run kill @e[type=minecraft:marker,tag=mithril_node,distance=..0.1]
summon minecraft:marker ~2 ~-1 ~2 {Tags:["mithril_node","mithril_cyan_terracotta"]}
setblock ~2 ~ ~-2 minecraft:cyan_terracotta
execute positioned ~2 ~ ~-2 run kill @e[type=minecraft:marker,tag=mithril_node,distance=..0.1]
summon minecraft:marker ~2 ~ ~-2 {Tags:["mithril_node","mithril_cyan_terracotta"]}
setblock ~2 ~ ~-1 minecraft:cyan_terracotta
execute positioned ~2 ~ ~-1 run kill @e[type=minecraft:marker,tag=mithril_node,distance=..0.1]
summon minecraft:marker ~2 ~ ~-1 {Tags:["mithril_node","mithril_cyan_terracotta"]}
setblock ~2 ~ ~ minecraft:gray_wool
execute positioned ~2 ~ ~ run kill @e[type=minecraft:marker,tag=mithril_node,distance=..0.1]
summon minecraft:marker ~2 ~ ~ {Tags:["mithril_node","mithril_gray_wool"]}
setblock ~2 ~ ~1 minecraft:prismarine
execute positioned ~2 ~ ~1 run kill @e[type=minecraft:marker,tag=mithril_node,distance=..0.1]
summon minecraft:marker ~2 ~ ~1 {Tags:["mithril_node","mithril_prismarine"]}
setblock ~2 ~ ~2 minecraft:prismarine
execute positioned ~2 ~ ~2 run kill @e[type=minecraft:marker,tag=mithril_node,distance=..0.1]
summon minecraft:marker ~2 ~ ~2 {Tags:["mithril_node","mithril_prismarine"]}
setblock ~2 ~1 ~-2 minecraft:prismarine
execute positioned ~2 ~1 ~-2 run kill @e[type=minecraft:marker,tag=mithril_node,distance=..0.1]
summon minecraft:marker ~2 ~1 ~-2 {Tags:["mithril_node","mithril_prismarine"]}
setblock ~2 ~1 ~-1 minecraft:prismarine
execute positioned ~2 ~1 ~-1 run kill @e[type=minecraft:marker,tag=mithril_node,distance=..0.1]
summon minecraft:marker ~2 ~1 ~-1 {Tags:["mithril_node","mithril_prismarine"]}
setblock ~2 ~1 ~ minecraft:prismarine
execute positioned ~2 ~1 ~ run kill @e[type=minecraft:marker,tag=mithril_node,distance=..0.1]
summon minecraft:marker ~2 ~1 ~ {Tags:["mithril_node","mithril_prismarine"]}
setblock ~2 ~1 ~1 minecraft:light_blue_wool
execute positioned ~2 ~1 ~1 run kill @e[type=minecraft:marker,tag=mithril_node,distance=..0.1]
summon minecraft:marker ~2 ~1 ~1 {Tags:["mithril_node","mithril_light_blue_wool"]}
setblock ~2 ~1 ~2 minecraft:prismarine_bricks
execute positioned ~2 ~1 ~2 run kill @e[type=minecraft:marker,tag=mithril_node,distance=..0.1]
summon minecraft:marker ~2 ~1 ~2 {Tags:["mithril_node","mithril_prismarine_bricks"]}
setblock ~2 ~2 ~-2 minecraft:light_blue_wool
execute positioned ~2 ~2 ~-2 run kill @e[type=minecraft:marker,tag=mithril_node,distance=..0.1]
summon minecraft:marker ~2 ~2 ~-2 {Tags:["mithril_node","mithril_light_blue_wool"]}
setblock ~2 ~2 ~-1 minecraft:prismarine_bricks
execute positioned ~2 ~2 ~-1 run kill @e[type=minecraft:marker,tag=mithril_node,distance=..0.1]
summon minecraft:marker ~2 ~2 ~-1 {Tags:["mithril_node","mithril_prismarine_bricks"]}
setblock ~2 ~2 ~ minecraft:prismarine_bricks
execute positioned ~2 ~2 ~ run kill @e[type=minecraft:marker,tag=mithril_node,distance=..0.1]
summon minecraft:marker ~2 ~2 ~ {Tags:["mithril_node","mithril_prismarine_bricks"]}
setblock ~2 ~2 ~1 minecraft:dark_prismarine
execute positioned ~2 ~2 ~1 run kill @e[type=minecraft:marker,tag=mithril_node,distance=..0.1]
summon minecraft:marker ~2 ~2 ~1 {Tags:["mithril_node","mithril_dark_prismarine"]}
setblock ~2 ~2 ~2 minecraft:cyan_terracotta
execute positioned ~2 ~2 ~2 run kill @e[type=minecraft:marker,tag=mithril_node,distance=..0.1]
summon minecraft:marker ~2 ~2 ~2 {Tags:["mithril_node","mithril_cyan_terracotta"]}
execute as @e[type=minecraft:marker,tag=mithril_node] run scoreboard players set @s mithril_timer 0
tellraw @a {"text":"Dwarven Mithril cube created at 0 64 0","color":"aqua"}

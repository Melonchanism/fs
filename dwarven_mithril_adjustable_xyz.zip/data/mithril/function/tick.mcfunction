execute as @e[type=minecraft:marker,tag=mithril_node] at @s run function mithril:node_tick

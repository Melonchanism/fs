kill @e[type=minecraft:marker,tag=mithril_node]

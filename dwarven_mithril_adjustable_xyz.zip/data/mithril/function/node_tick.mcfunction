execute if score @s mithril_timer matches 0 if block ~ ~ ~ minecraft:air run function mithril:mined
execute if score @s mithril_timer matches 1.. run scoreboard players remove @s mithril_timer 1
execute if score @s mithril_timer matches 0 if block ~ ~ ~ minecraft:bedrock run function mithril:regrow

execute store result score @s mithril_roll run random value 1..100
execute if score @s mithril_roll matches 1..98 if entity @s[tag=mithril_light_blue_wool] run setblock ~ ~ ~ minecraft:light_blue_wool
execute if score @s mithril_roll matches 1..98 if entity @s[tag=mithril_prismarine_bricks] run setblock ~ ~ ~ minecraft:prismarine_bricks
execute if score @s mithril_roll matches 1..98 if entity @s[tag=mithril_dark_prismarine] run setblock ~ ~ ~ minecraft:dark_prismarine
execute if score @s mithril_roll matches 1..98 if entity @s[tag=mithril_cyan_terracotta] run setblock ~ ~ ~ minecraft:cyan_terracotta
execute if score @s mithril_roll matches 1..98 if entity @s[tag=mithril_gray_wool] run setblock ~ ~ ~ minecraft:gray_wool
execute if score @s mithril_roll matches 1..98 if entity @s[tag=mithril_prismarine] run setblock ~ ~ ~ minecraft:prismarine
execute if score @s mithril_roll matches 99..100 run setblock ~ ~ ~ minecraft:polished_diorite

setblock ~ ~ ~ minecraft:bedrock
scoreboard players set @s mithril_timer 101
playsound minecraft:block.amethyst_block.break block @a[distance=..12] ~ ~ ~ 0.4 0.8
